# GameProject

To compile the project, enter the terminal command with GameProject folder as the current directory:

```
javac -sourcepath src src/*.java -d bin
```

To run the project, enter the terminal command also from GameProject folder:

```
java -classpath bin Console
```


