package story;

import java.util.Arrays;

import format.Billboard;
import logic.DataManager;

/**
 * This class takes care of describing what is happening in the story events of our game.
 * It is much easier to keep track of all the parts of our story in one place: this class.
 */
public class Narrator {
	// There is only one interactive story, so all methods are static.
	private final static int MAX_LINE_WIDTH = Billboard.getMaxLineWidth();
	private final static int FINAL_CHAPTER = 2;
	private static int chapter = 0;
	private static DataManager data;
	
	// If everything is static, then we never need a constructor.
	// All variables only store one primitive value, or one instance of an object.
	// All methods can execute on the shared variables above.
	
	/**
	 * Connect to the same data instance used by the Game. So the Narrator can know
	 * what the player's name is, and whether they have died or not.
	 * 
	 * @param data
	 *   Should pass in the same data instance used by the Game.
	 */
	public static void setData(DataManager data) {
		Narrator.data = data; // instance shared by Game, Narrator
	}
	
	/**
	 * A helper method to convert a string into an array of strings for
	 * display within a Billboard instance.
	 *
	 * @param narrative
	 *   The part of the story to break into substring lines.
	 *
	 * @return
	 *   The array of string elements that results from breaking
	 *   up the narrative string into lines of maximum length to fit
	 *   within a Billboard instance.
	 */
	public static String[] splitStringforBillboard(String narrative) {
		int len = narrative.length();
		// Always round up, because leftover chars will need 
		// to be in the last line.
		int width = Billboard.getMaxLineWidth();
		int lines = (int)Math.ceil((double)len / width);
		String[] result = new String[lines];
		int i;
		for (i = 0; i < lines-1; i++) {
			result[i] = narrative.substring(i*width, (i+1)*width);
		}
		result[lines-1] = narrative.substring(i*width, narrative.length());
		return result;
	}
	
	/**
	 * A method to get the different parts of our story. Each time this method is
	 * executed, the chapter number advances by one value. Extend the given code,
	 * or you could design your story to behave in a completely different way if 
	 * you want. For example, creating descriptions of your story or character 
	 * dialogue as strings in an array or collection, and choosing parts of it 
	 * in different ways, perhaps partly random.
	 *
	 * @return
	 *   An array of string descriptions.
	 */
	public static String[] tell() {
		if (data.isPlayerChosen() && data.isPlayerDead()) {
			chapter = FINAL_CHAPTER;
		}
		
		// we will not need break statements if we return instead
		switch (chapter++) {
			case 0:
				return begin();
			case 1:
				return chapter1();
			// case 2:
				// return chapter2(); // if you choose to write a story, add four more chapters
			case FINAL_CHAPTER:
				return end(); // change the number for FINAL_CHAPTER as part of your design
			default:
				return new String[] { "No chapter content. (this message is for help with debugging)" };
		}
	}
	
	// The start of the story.
	private static String[] begin() {
		/* 
		 * String of dashes below is example of maximum length line we can have in
		 * a Billboard (Billboard.getMaxLineWidth()), which is designed to throw 
		 * IllegalArgumentExceptions. This forces other programmers to follow your
		 * method designs and get useful debug error messages that are expected from
		 * taking advantage of exceptions.
		 *  "--------------------------------------------------------------"
		 */
		// we put centred short lines in a Billboard by making our own String array
		String[] intro = {
			"Hello, " + data.getUserName() + "!",
			"--- Monster's Tempest ---",
			"", // a blank line
			"You have arrived at the Forest of Monsters",
			"get rid of the monsters so they won't scare ",
			"any of the villagers."
		};
		return intro;
	}
	
	// You could give your own methods useful scene names to help yourself
	// keep track of what parts of your story are about.
	private static String[] chapter1() {
		// let splitStringforBillboard() worry about where to split the lines of text
		String prose = 
			"You want to buy a house in the village at  " +
			"the edge of the forest. " +
			"Here comes the waves of monsters. Be Careful!";
		return combine(splitStringforBillboard(prose), data.describeMonsters());
	}
	
	// Demonstrating how two different ways the code can 
	// give different endings to the story.
	private static String[] end() {
		String ending;
		if (data.isPlayerDead()) 
			ending = 
				"Your player has died..." +
				"Thank you for playing!";
		else
			ending = 
				"Thanks to you the villagers can live without worrying" +
				"You are revered as a hero and the villagers make you their village head!";
		
		return splitStringforBillboard(ending);
	}
	
	/**
	 * Checks if the Narrator is ready to end its story.
	 * This helps Game know what to do next. Perhaps you
	 * could check similarly for other chapters?
	 *
	 * @return
	 *   Returns <code>true</code> if the Narrator is currently about 
	 *   to tell the final chapter in the story, and <code>false</code> otherwise.
	 */
	public static boolean isAtFinalChapter() {
		return chapter == FINAL_CHAPTER;
	}
	
	// A helper method to sequence together two string arrays into one array.
	private static String[] combine(String[] first, String[] second) {
		// Copy the first, and make enough extra space for the second.
		String[] combined = Arrays.copyOf(first, first.length + second.length);
		// Copy the second into the extra space.
		System.arraycopy(second, 0, combined, first.length, second.length);
		return combined;
	}
	
}
