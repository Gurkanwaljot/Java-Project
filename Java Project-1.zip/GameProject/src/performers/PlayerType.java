package performers;

/**
 * This organizes the player's choices for what type of person they can play.
 * 
 * @author Dr Russell Campbell
 *
 */
public enum PlayerType {
	Haigrid,
	HarryPotter;
	
}
