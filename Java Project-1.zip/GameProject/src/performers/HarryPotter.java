package performers;

import logic.Random;

/**
 * YOU NEED TO WRITE THE JAVADOC. Write doc comments for all methods.
 * 
 * @author jincheng Gao
 *
 * @param 
 *   the effect of how player attack
 * @param  
 *   the effect of how player cast
 * @param
 *   the effect of how player defend
 *
 *
 */
public class HarryPotter extends Player {
	
	public HarryPotter() {
		// *If* you call the superclass constructor, make sure you call it first.
		super(
			Random.rand(50) + 50,  // hitPoints
			Random.rand(20) + 20,   // strength is within [5, 25)
			Random.rand(30) + 30 // wisdom is within [20, 100)
		);
		// Then initialize other variables after...
		
	}
	
	@Override
	public String[] attack(Monster... monsters) {
	        
		String[] results = new String[monsters.length + 1];
		int i = 0;
		
		results[i++] = "HarryPotter attack!";
		
		// Randomly damage each monster passed in.javac -sourcepath src src/*.java -d bin
		for (Monster mnstr : monsters) {
			// Design your own calculations.
			int damage = Random.rand(strength) + 30;
			mnstr.damageHitPoints(damage);
			// Describe stats on this monster.
			results[i++] = 
				"- hit 1111" +
				mnstr.getDescription() +
				" with 1111 " + 
				damage +
				" damage 1111;" +
				" it has " + 
				mnstr.getHitPoints() +
				" hit points remaining 0.";
		}
		
		return results;
	}

	@Override
	public String[] castSpell(Monster... monsters) {

		String[] results = new String[monsters.length + 1];
		int i = 0;
		results[i++] = "HarryPotter castSpell!";
		for (Monster mnstr : monsters) {
			// Design your own calculations.
			int damage = Random.rand(wisdom) + 30;
			mnstr.damageHitPoints(damage);
			// Describe stats on this monster.
			results[i++] = 
				"- hit" +
				mnstr.getDescription() +
				" with " + 
				damage +
				" damage;" +
				" it has " + 
				mnstr.getHitPoints() +
				" hit points remaining.";
		}
		
		return results;
	}
	
	@Override
	public String[] defend(Player... player) {
	
	       String[] results = new String[player.length];
	       int i = 0;
	       results[i++] = "HarryPotter recover his hitPoints!" + strength;
	       for (Player plyr : player) {
	       int recover = Random.rand(strength) + 30;
	       plyr.recoverHitPoints(recover);
	       
	      }
	      return results;
	      
       }
	


}
