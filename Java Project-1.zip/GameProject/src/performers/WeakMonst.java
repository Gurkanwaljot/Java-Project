package performers;

import java.awt.Color;
import gui.Panel2D;
import graphics.Point2D;
import logic.Random;

/**
 * Weak monster that once defeated will give the player more hit points once defeated
 * Babanpreet Kelay
*/

public class WeakMonst extends Monster {
	
	private Point2D location;
	private Point2D centre;
	
	public WeakMonst() {
		super(
			Random.rand(5) + 1, //the weak monster's hitpoints
			Random.rand(15) + 10 // the weak monster's strength
		);	
		
	}
	
	
	
	public Point2D getLocation() {
		return location;
	}
	
	public boolean isMonsterLoc(){
		return this.location.x == 5 && this.location.y == 2;
	}
	public boolean isMonsterLoc1(){
		return this.location.x == 6 && this.location.y == 5;
	}
	public boolean isMonsterLoc2(){
		return this.location.x == 4 && this.location.y == 5;
	}
	public boolean isMonsterLoc3(){
		return this.location.x == 1 && this.location.y == 4;
	}
	
	/**
	 * A basic attack for the Troll type of monster.
	 * 
	 * @param plyr
	 *   The person the user is using to play the game.
	 * 
	 * @return
	 *   An array of strings, describing the results of a Troll attack on the player.
	 */
	@Override
	public String[] attack(Player plyr) {
		plyr.damageHitPoints(8);
		return new String[] { "Troll attacked you for " + 8 + " damage!" };
	}
	
	/**
	 * A more descriptive result to go along with a Troll's unique spell (or ability) to cast.
	 * 
	 * @param plyr
	 *   The person the user is using to play the game.
	 * 
	 * @return
	 *   An array of strings, describing the results of a Troll's spell on the player.
	 */
	@Override
	public String[] castSpell(Player plyr) {
		plyr.damageHitPoints(6);
		return new String[] {
			"The Troll gets angry and stomps and throws punches",
			"The imapct of Troll rage causes " + 6 + " damage!"
		};
	}
	
	/**
	 * Get a Troll description.
	 * 
	 * @return
	 *   A short phrase describing a Troll. You could randomize descriptions
	 *   to be unique for different instances in different ways.
	 */
	@Override
	public String getDescription() {
		return "Hill Troll looking for food";
	}
}
