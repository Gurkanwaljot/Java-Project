package performers;

import java.awt.Color;
import gui.Panel2D;
import graphics.Point2D;
import logic.Random;

/**
 * Strong monster that is harder to kill the player has to collect hit points so the 
 * monster can be defeated
 * Babanpreet Kelay
*/

public class StrongMonst extends Monster {
	
	private Point2D location;
	private Point2D centre;
	
	public StrongMonst() {
		super(
			Random.rand(15) + 10, //the weak monster's hitpoints
			Random.rand(25) + 10 // the weak monster's strength
		);	
		
	}
	
	
	
	public Point2D getLocation() {
		return location;
	
	}
	
	
	public boolean isMonsterLoc4(){
		return this.location.x == 5 && this.location.y == 6;
	}
	public boolean isMonsterLoc5(){
		return this.location.x == 3 && this.location.y == 3;
	}
	
	/**
	 * A basic attack for the Troll type of monster.
	 * 
	 * @param plyr
	 *   The person the user is using to play the game.
	 * 
	 * @return
	 *   An array of strings, describing the results of a Troll attack on the player.
	 */
	@Override
	public String[] attack(Player plyr) {
		plyr.damageHitPoints(8);
		return new String[] { "Troll attacked you for " + 8 + " damage!" };
	}
	
	/**
	 * A more descriptive result to go along with a Troll's unique spell (or ability) to cast.
	 * 
	 * @param plyr
	 *   The person the user is using to play the game.
	 * 
	 * @return
	 *   An array of strings, describing the results of a Troll's spell on the player.
	 */
	@Override
	public String[] castSpell(Player plyr) {
		plyr.damageHitPoints(6);
		return new String[] {
			"The Troll gets angry and stomps and throws punches",
			"The imapct of Troll rage causes " + 6 + " damage!"
		};
	}
	
	/**
	 * Get a Troll description.
	 * 
	 * @return
	 *   A short phrase describing a Troll. You could randomize descriptions
	 *   to be unique for different instances in different ways.
	 */
	@Override
	public String getDescription() {
		return "Hill Troll looking for food";
	}
}
