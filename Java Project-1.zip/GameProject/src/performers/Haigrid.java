package performers;

import logic.Random;
/**
 * YOU NEED TO WRITE THE JAVADOC. Write doc comments for all methods.
 * 
 * @author Jincheng Gao
 *
 * @param attack 
 *   the effect of how player attack
 * @param castSpell  
 *   the effect of how player cast
 * @param defend
 *   the effect of how player defend
 *
 */
public class Haigrid extends Player {

	
	public Haigrid() {
		// *If* you call the superclass constructor, make sure you call it first.
		super(
			Random.rand(60) + 60,  // hitPoints start with the max
			Random.rand(20) + 20, // strength is within [20, 100)
			Random.rand(10) + 10   // wisdom is within [5, 25)
		);
		// Then initialize other variables after...
		
	}
	
	@Override
	public String[] attack(Monster... monsters) {
		// Recall that ... is called "variable arguments" (textbook, pg 93).
		// Basically, you can use monsters like an array of strings.
		String[] results = new String[monsters.length + 1];
		int i = 0;
		results[i++] = "Haigrid attack!";
		
		// Randomly damage each monster passed in.javac -sourcepath src src/*.java -d bin
		for (Monster mnstr : monsters) {
			// Design your own calculations.
			int damage = Random.rand(strength) + 10;
			mnstr.damageHitPoints(damage);
			// Describe stats on this monster.
			results[i++] = 
				"- hit" +
				mnstr.getDescription() +
				" with " + 
				damage +
				" damage;" +
				" it has " + 
				mnstr.getHitPoints() +
				" hit points remaining.";
		}
		
		return results;
		
	}

	@Override
	public String[] castSpell(Monster... monsters) {

		String[] results = new String[monsters.length + 1];
		int i = 0;
		results[i++] = "Haigrid castSpell!";
		for (Monster mnstr : monsters) {
			// Design your own calculations.
			int damage = Random.rand(wisdom) + 20;
			mnstr.damageHitPoints(damage);
			// Describe stats on this monster.
			results[i++] = 
				"- hit" +
				mnstr.getDescription() +
				" with " + 
				damage +
				" damage;" +
				" it has " + 
				mnstr.getHitPoints() +
				" hit points remaining.";
		}
		
		return results;
	}
	
	
	@Override
	public String[] defend(Player... player) {
	
	       String[] results = new String[player.length];
	       int i = 0;
	       results[i++] = "Haigrid recover his hitPoints" ;
	       for (Player plyr : player) {
	       int recover = Random.rand(strength) + 30;
	       plyr.recoverHitPoints(recover);
	       
	      }
	      return results;
	      
       }
         
       
}
