package graphics;

import java.awt.Color;
import gui.Panel2D;
// Arshdeep Kaur
public class Slider extends Box{
	
	
	
	private Point2D position; // bottom left corner of cube
	
	
	public Slider(int x1, int y1, Color color, char[][] design) {
		super(x1, y1, color);
		position = new Point2D(x1, y1);
	}
	
	private void moveCorners(int x1, int y1) {
		// Clockwise order.
	}
	
	private void update() {
		
	}
	
	@Override
	public Color getColor() {
		return color;
	}
	
	private void update() {
		if (centre.x < 1 || parentPanel.getWidth() < centre.x+2)  dx *= -1;
		if (centre.y < 1 || parentPanel.getHeight() < centre.y+2) dy *= -1;
		// NOTE: if dx1, dy1, dx2, dy2 have magnitude smaller than 1, then the range
		// tests above must be restricted further, or else Box points can get stuck
		moveCentre(dx, dy);
	}
	
}
