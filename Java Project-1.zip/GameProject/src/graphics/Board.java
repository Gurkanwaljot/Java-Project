package graphics;

import java.util.ArrayList;

import gui.AnimatedGUI;
import gui.Panel2D;

public class Board{

	static Point2D origin; 
	ArrayList<Drawable> actors;
	AnimatedGUI window;
	
	
	static int[][] map = {
		{ 1, 1, 1, 1, 1, 1, 1, 1 },
		{ 1, 2, 2, 1, 1, 1, 1, 1 },
		{ 1, 1, 2, 1, 2, 2, 1, 1 },
		{ 1, 1, 1, 1, 2, 2, 1, 1 },
		{ 1, 1, 1, 2, 5, 2, 1, 1 },
		{ 1, 1, 1, 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 1, 1, 1, 1 }
	};
	
	public Board(ArrayList<Drawable> actors, AnimatedGUI window) {

		int width  = window.getPanel2D().getWidth();
		int height = window.getPanel2D().getHeight();
		origin = new Point2D(-width/2, height/2); 
		this.actors = actors;
		this.window = window;
		
		
		for (int layer = 1; layer < 6; layer++) {
			createLayer(layer);	
		}
	
	
	}
	
	private void createLayer(int layer) {
		for (int row = 7; row >= 0; row--) {
			createRow(layer, row);	
		}
		
	}
	
	private void createRow(int layer, int row){
		for (int col = 0; col < 8; col++) {
			createCol(layer, row, col);
		}
		
		
	}
	
	private void createCol(int layer, int row, int col){
		if (map[7 - row][col] >= layer) { 
			Point2D tileSpot = getTileCorner(layer, row, col);
			actors.add(
				new Box(
					tileSpot.x, 
					tileSpot.y, 
					Panel2D.Orange[row]
				)
			);
			actors.get(actors.size()-1).setParent(window.getPanel2D());
			window.getPanel2D().setActors(actors);
		}
	}
	
	private Point2D getTileCorner (int layer, int row, int col) {
		int x = origin.x + row*5 + col*5;
		int y = origin.y + row*2 - col*2 + 2*layer;
		return new Point2D(x,y);
	
	}
	
	public static Point2D getTileCentre( int col, int row){
		int x = origin.x + row*3 + col*5 + 4;
		int y = origin.y + row*2 - col*2 + 2*(map[7-row][col]-1) + 3; 
		return new Point2D(x, y);
	
	}
}
