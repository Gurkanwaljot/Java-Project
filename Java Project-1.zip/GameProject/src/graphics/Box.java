package graphics;

import java.awt.Color;
import gui.Panel2D;

/**
 * A shape of a cube in its <code>Panel2D parentPanel</code>.
 * 
 * @author Dr Russell Campbell
 */
public class Box extends Shape {
	
	private char[][] design = {
		"XXX▄██▄XXX".toCharArray(),
		"X■██████■X".toCharArray(),
		"X|▀████▀|X".toCharArray(),
		"X|░░||▒▒|X".toCharArray(),
		"XX░░||▒▒XX".toCharArray()
	};
	
	private Point2D position; // bottom left corner of cube
	
	/**
	 * Create an instance of a rectangle shape and set up a formula to 
	 * conrol its movement for animation.
	 * 
	 * @param x1 
	 *   Horizontal position of the top-left corner.
	 * @param y1 
	 *   Vertical position of the top-left corner.
	 * @param color
	 *   The index of the colour used to draw the rectangle.
	 */
	public Box(int x1, int y1, Color color) {
		super('`', color);
		position = new Point2D(x1, y1);
	}
	
	private void moveCorners(int x1, int y1) {
		// Clockwise order.
	}
	
	private void update() {
		
	}
	
	@Override
	public Color getColor() {
		return color;
	}
	
	
	/**
	 * Moves, and then draws this rectangle shape in its <code>parentPanel</code>.
	 */
	@Override
	public void draw() {
		update();
		for (int row = design.length-1; row >= 0; row--) {
			for (int col = 0; col < design[row].length; col++) {
				Color shade;
				if (design[row][col] == '▒')
					shade = Panel2D.getColor(Panel2D.LIGHT_BLUE);
				else
					shade = color;
				if (design[row][col] != 'X') {
					parentPanel.set(
						position.x + col, 
						position.y - row, 
						design[row][col],
						shade
					);
				}
			}
		}
	}
	
}
