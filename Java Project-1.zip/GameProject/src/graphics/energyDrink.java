// Done by Gurkanwaljot Singh Brar
//Draws item named energy drink.

package graphics;

import java.awt.Color;
import gui.Panel2D;
import logic.DataManager;
import logic.Game;
import logic.OutputManager;



public class energyDrink extends Shape {
	
	private Point2D location;
	private Point2D centre;
	private int height;
	private int width;
	private int dx, dy;
	private static OutputManager out = new OutputManager();
	private static DataManager data = new DataManager();
	public static int DrinkPoints = 0;
	static String playerItem ;
	private static Circle circle;
	public static int totalPoints = 0;
	
	

	public energyDrink(Point2D centre, int width, int height, char c, Color color) {
		// If we do call it, we must call super first.
		super(c, color); 
		this.centre = centre;
		this.width = width;
		this.height = height;
		
		dx = dy = 1; // diagonal motion
	}
	
	public Point2D getLocation() {
		return location;
	
	}
	
	public void setLocation(Point2D pt){
		location = pt;
		setCentre(location);
	}
	
	
	private void setCentre(Point2D pt){
		centre = Board.getTileCentre(location.x, location.y);
	
	}
	
	private void moveCentre(int x, int y) {
		centre.translate(x, y);
	}
	
//	private void update() {
//		if (centre.x < 1 || parentPanel.getWidth() < centre.x+2)  dx *= -1;
//		if (centre.y < 1 || parentPanel.getHeight() < centre.y+2) dy *= -1;
//		moveCentre(dx, dy);
//	}
	
	@Override
	public Color getColor() {
		return color;
	}
	
	@Override
	public void draw() {
		//update();
		Point2D bottomLeft = centre.add(new Point2D(-width/2, -height/2));
		Point2D bottomRight = centre.add(new Point2D(width/2, -height/2));
		Point2D topLeft = centre.add(new Point2D(-width/2, height/2));
		Point2D topRight = centre.add(new Point2D(width/2, height/2));
		
		parentPanel.drawLine(bottomLeft, bottomRight, c, color);
		parentPanel.drawLine(bottomRight, topRight, c, color);
		parentPanel.drawLine(topRight, topLeft, c, color);
		parentPanel.drawLine(topLeft, bottomLeft, c, color);

	}
	public static void pickedUpDrink(){
			playerItem = "Energy Drink";
			out.printInfoIO("You got a " + playerItem + "." + playerItem
					+ "is a power booster drink that increases the hit points of the player by 25");
			 totalPoints = Game.totalPoints + 25;
			out.printInfoStats(data.getUserName() + "'s hit points and energy drink points: " + totalPoints);
			out.printBlankLineStats();
	}
}