// Done by Gurkanwaljot Singh Brar
// Draws the apple 


package graphics;

import java.awt.Color;
import java.util.ArrayList;
import gui.Panel2D;
import logic.DataManager;
import logic.OutputManager;
import logic.Game;


public class Apple extends Shape {
	
	private Point2D location;
	private Point2D centre;
	private int height;
	private int width;
	private int dx, dy;
	static String playerItem ;
	private static OutputManager out = new OutputManager();
	private static DataManager data = new DataManager();
	public static int totalPoints= 0;
	private static Circle circle;

	public Apple(Point2D centre, int width, int height, char c, Color color) {
		// If we do call it, we must call super first.
		super(c, color); 
		this.centre = centre;
		this.width = width;
		this.height = height;
		
		dx = dy = 1; // diagonal motion
	}
	
	public Point2D getLocation() {
		return location;
	
	}
	
	public void setLocation(Point2D pt){
		location = pt;
		setCentre(location);
	}
	
	
	private void setCentre(Point2D pt){
		centre = Board.getTileCentre(location.x, location.y);
	
	}
	
	private void moveCentre(int x, int y) {
		centre.translate(x, y);
	}
//	
//	private void update() {
//		if (centre.x < 1 || parentPanel.getWidth() < centre.x+2)  dx *= -1;
//		if (centre.y < 1 || parentPanel.getHeight() < centre.y+2) dy *= -1;
//		moveCentre(dx, dy);
//	}
	
	@Override
	public Color getColor() {
		return color;
	}
	
	@Override
	public void draw() {
		Point2D bottomLeft = centre.add(new Point2D(-width/2, -height/2));
		Point2D bottomRight = centre.add(new Point2D(width/2, -height/2));
		Point2D topRight = centre.add(new Point2D(width/2, height/2));
		
		parentPanel.drawLine(bottomLeft, bottomRight, c, color);
		parentPanel.drawLine(topRight, bottomRight, c, color);
		parentPanel.drawLine(topRight, bottomLeft, c, color);
	}
	
	public static void pickedUpApple(){
			playerItem = "Apple";
			out.printInfoIO("You got a " + playerItem + "." + playerItem
					+ " is a booster that increases the hit points of the player by" + " 10 points.");
			int totalpoints = Game.totalPoints + 10;
			out.printInfoStats(data.getUserName() + "'s hit points and apple points: " + totalpoints);
			out.printBlankLineStats();
		
	}
	
}
