package logic;

import java.awt.Color;
import javax.swing.SwingUtilities;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import graphics.Drawable;
import graphics.Point2D;
import graphics.Box;
import graphics.Board;
import graphics.Circle;
import graphics.Fuzzy;
import graphics.Weapon;
import graphics.energyDrink;
import graphics.Apple;
import graphics.MonsterIcon;
import gui.AnimatedGUI;
import gui.Panel2D;
import performers.Player;
import performers.Monster;
import story.Narrator;

/**
 * This is the class that will manage all parts of the game, bringing them
 * together. Its execution sets up the application window, begins other threads
 * for animation, and loops through the story of the game until the user either
 * wins or loses.
 * 
 * @author Dr Russell Campbell
 *
 */
public class Game {

	// Only need one instance of each piece of the game, so they can all be static.

	// For the main application window for our program.
	private static AnimatedGUI window;
	// For the separate execution of our game logic.
	private static Thread gameThread;
	// For controlling the sharing of information between parts of our game.
	private static InputManager in = new InputManager();
	private static OutputManager out = new OutputManager();
	private static DataManager data = new DataManager();

	// For performers within our game that can do various interesting things.
	private static Board board;
	private static Circle circle;
	public static Player plyr;
	private static Weapon weapon;
	private static graphics.Apple apple;
	private static graphics.energyDrink energyDrink;
	private static MonsterIcon troll;
	private static ArrayList<Monster> monsters;
	// How many monsters the player must defeat.
	private static final int N_MONSTERS = 6;
	private static String playerItem;
	public static int totalPoints;

	/**
	 * This is where the game begins.
	 */
	public void play() {

		setupApplicationWindow();
		setupAnimations(null, null);

		GameThread gameThread = new GameThread();
		in.setGameThread(gameThread);
		window.getPanelIO().setGameThread(gameThread);
		gameThread.start(); // begins execution of gameLoop method

		// Take special note of the small size of each method.
		// Small methods are easier to understand and debug.
	}

	private void setupApplicationWindow() {

		// our main application
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					window = new AnimatedGUI();
				}
			});
		} catch (InterruptedException | InvocationTargetException e) {
			e.printStackTrace();
		}

		// Connect GUI to the rest of our program.
		out.setPanelIO(window.getPanelIO());
		out.setPanelStats(window.getPanelStats());
		in.setPanelIO(window.getPanelIO());
	}

	private static void setupAnimations(Point2D circle_location, Point2D circle_location1) {
		// Now we have interfaces to let us collect objects that are NOT related.
		// This allows us to call the methods on each object in the collection described
		// in Drawable.

		ArrayList<Drawable> actors = new ArrayList<Drawable>();
		board = new Board(actors, window);

		// Can still change actors after connecting with Panel2D.
		if (circle_location == null) {
			Point2D circleSpot = board.getTileCentre(5, 0);
			circle = new Circle(circleSpot.x, circleSpot.y, 2, '*', Panel2D.getColor(Panel2D.BLUE));
			circle.setLocation(new Point2D(5,0));
			actors.add(circle);
			circle.setParent(window.getPanel2D());
		} else {
			circle = new Circle(circle_location.x, circle_location.y, 2, '*', Panel2D.getColor(Panel2D.BLUE));
			circle.setLocation(circle_location);
			actors.add(circle);
			circle.setParent(window.getPanel2D());
		}

		// weak monster icons
		// Babanpreet Kela
		Point2D wemoSpot = board.getTileCentre(5, 2);
		troll = new MonsterIcon(wemoSpot.x, wemoSpot.y, 1, '*', Panel2D.getColor(Panel2D.MAGENTA));
		troll.setLocation(new Point2D(5, 2));
		actors.add(troll);
		// troll.setParent(window.getPanel2D());

		Point2D wemo1Spot = board.getTileCentre(6, 5);
		troll = new MonsterIcon(wemo1Spot.x, wemo1Spot.y, 1, '*', Panel2D.getColor(Panel2D.MAGENTA));
		troll.setLocation(new Point2D(6, 5));
		actors.add(troll);

		Point2D wemo2Spot = board.getTileCentre(4, 5);
		troll = new MonsterIcon(wemo2Spot.x, wemo2Spot.y, 1, '*', Panel2D.getColor(Panel2D.MAGENTA));
		troll.setLocation(new Point2D(4, 5));
		actors.add(troll);

		Point2D wemo3Spot = board.getTileCentre(1, 4);
		troll = new MonsterIcon(wemo2Spot.x, wemo3Spot.y, 1, '*', Panel2D.getColor(Panel2D.MAGENTA));
		troll.setLocation(new Point2D(1, 4));
		actors.add(troll);
		// Strong monster icons
		// Babanpreet Kelay
		Point2D weSpot = board.getTileCentre(5, 6);
		troll = new MonsterIcon(weSpot.x, weSpot.y, 1, '*', Panel2D.getColor(Panel2D.GREEN));
		troll.setLocation(new Point2D(5, 6));
		actors.add(troll);

		Point2D we1Spot = board.getTileCentre(3, 3);
		troll = new MonsterIcon(we1Spot.x, we1Spot.y, 1, '*', Panel2D.getColor(Panel2D.GREEN));
		troll.setLocation(new Point2D(3, 3));
		actors.add(troll);
	// GURKANWALJOT SINGH BRAR
		int x1 = 0;
		int y1 = 0;
		int i = 0;
		int x2 = 0;
		int y2 = 0;
		int i1 = 0;
		char[] itemDesign1 = { '$', '$', '$' };
		char[] itemDesign = { '@', '@', '@' };
		
		for (i = 0; i<2; i++) {
			for(x1 = 2, y1 = 3; x1 < 5 && y1 < 6; x1++, y1++) {
				energyDrink = new graphics.energyDrink(new Point2D(5, 0), 2, 3, itemDesign[i],
						Panel2D.getColor(Panel2D.MAGENTA));
				energyDrink.setLocation(new Point2D(x1, y1));
	
				actors.add(energyDrink);
				energyDrink.setParent(window.getPanel2D());
			}
		}

		for (i1 = 0; i1 < 3; i1++) {
			for(x2 = 4, y2 =2; x2<7 && y2 > -1; x2++, y2--) {
				apple = new graphics.Apple(new Point2D(5, 0), 2, 3, itemDesign1[i1], Panel2D.getColor(Panel2D.CYAN));
				apple.setLocation(new Point2D(x2, y2));
	
				actors.add(apple);
				apple.setParent(window.getPanel2D());
			}

		}
		
		Point2D weaponSpot = board.getTileCentre(4, 0);
		weapon = new Weapon(weaponSpot.x, weaponSpot.y, 1, '>', Panel2D.getColor(Panel2D.BLUE));
		weapon.setLocation(new Point2D(4, 0));
		actors.add(weapon);
		
		if(circle_location1 != null) {
			energyDrink = new graphics.energyDrink(new Point2D(6, 0), 2, 3, '@', Panel2D.getColor(Panel2D.MAGENTA));
			energyDrink.setLocation(circle_location1);
	
			actors.add(energyDrink);
			energyDrink.setParent(window.getPanel2D());
	
			actors.get(actors.size() - 1).setParent(window.getPanel2D());
			window.beginAnimation(); // same concepts as in Assignment 2
		}else {
			energyDrink = new graphics.energyDrink(new Point2D(6, 0), 2, 3, '@', Panel2D.getColor(Panel2D.MAGENTA));
			energyDrink.setLocation(new Point2D(0,0));
	
			actors.add(energyDrink);
			energyDrink.setParent(window.getPanel2D());
		}
			actors.get(actors.size() - 1).setParent(window.getPanel2D());
			window.beginAnimation(); // same concepts as in Assignment 2
		
	}

	public static void withinGameAnimations() {
//GURKANWALJOT SINGH BRAR
		if (circle.atposition4()) {
			ArrayList<Drawable> actors = new ArrayList<Drawable>();
			board = new Board(actors, window);
			Point2D location = new Point2D(4,2);
			Point2D location1 = new Point2D(4,4);
			setupAnimations(location, location1);

		} else if (circle.atposition5()) {
			ArrayList<Drawable> actors = new ArrayList<Drawable>();
			board = new Board(actors, window);
			Point2D location = new Point2D(5,1);
			Point2D location1 = new Point2D(6,2);
			setupAnimations(location, location1);

		} else if (circle.atposition6()) {
			ArrayList<Drawable> actors = new ArrayList<Drawable>();
			board = new Board(actors, window);
			Point2D location = new Point2D(6,0);
			Point2D location1 = new Point2D(7,0);
			setupAnimations(location, location1);

		}

	}

	/**
	 * The basic program flow-of-control for our game. You could design your own
	 * flow-of-control if you want to make a completely different game. The basic
	 * flow here is for every iteration to interact with the user, and then process
	 * their choices until the user either achieves their goal, or fails.
	 */
	static void gameLoop() {
		start();

		while (!Narrator.isAtFinalChapter()) {
			iteration(); // designed for Narrator to advance one chapter each iteration
		}

		finish();
	}

	/*
	 * The start of the game. Initialize and connect any part of the game that
	 * should be set up before the iteration loop.
	 */
	private static void start() {
		Narrator.setData(data);
		data.setUserName(in.getInputString("Please enter your name, traveller! (enter below)"));
		// Needed to store the user's name in data, because there is no Player intsance
		// created yet.
		// This is because the user still has to choose which subclass of Player they
		// want to be.

		out.printFancyIO(Narrator.tell());
		in.pause();

		int choice = in.getPlayerChoice();
		plyr = data.createPlayer(choice);
		data.setPlayer(plyr);
		out.printInfoIO(in.getHistory(0));

		monsters = new ArrayList<Monster>();
		data.createMonsters(monsters, N_MONSTERS);
	}

	/*
	 * This method is the part of the game that can be repeated. The basic idea is
	 * to give the player a choice, and then process that choice towards some kind
	 * of goal. Attacking monsters is a <b>very</b> common theme in many games.
	 */
	private static void iteration() {

		// Describe some interesting events.
		out.printFancyIO(Narrator.tell());

		// move within the isometric board
		playerMovement();
		withinGameAnimations();

		playerPrintStats();
		monsterPrintStats();
		in.pause();

		// Player and monsters take turns attacking each other until either has no hit
		// points.
		while (!monsters.isEmpty()) {

			playerAction();
			// You could design attacks on a random number of randomly chosen monsters.
			monsterActions();

			out.printInfoIO("You have " + plyr.getHitPoints() + " hit points left.");

			out.clearStats();
			playerPrintStats();
			monsterPrintStats();
			in.pause(); // give user time to absorb reading output of actions

			// No need to loop if player has no hit points remaining.
			if (plyr.isDead()) {
				// Narrator will give details of losing the game elsewhere.
				return;

			}

			out.printInfoIO("----------\\\\ YOU DEFEATED ALL THE MONSTERS! //----------");
			in.pause();
		}
	}

	private static void playerMovement() {

		int chanceOfAttack = Random.rand(100);
		while (chanceOfAttack < 70) {
			chanceOfAttack = Random.rand(100);
			int choice = in.getDirectionChoice();

			String[] result = new String[] { "no direction choosen yet" };
			Point2D location = circle.getLocation();
			switch (Directions.values()[choice]) {
			case NORTHWEST:
				location.translate(-1, 0);
				circle.setLocation(location);
				break;
			case NORTHEAST:
				location.translate(0, 1);
				circle.setLocation(location);
				break;
			case SOUTHWEST:
				location.translate(0, -1);
				circle.setLocation(location);
				break;
			case SOUTHEAST:
				location.translate(1, 0);
				circle.setLocation(location);
				break;

			}
			in.pause();
		}
	}

	// Let the player decide what they want to do in a monster battle.
	private static void playerAction() {

		int choice = in.getActionChoice();

		String[] results = new String[] { "no actions processed yet" };
		switch (Actions.values()[choice]) {

		case ATTACK:
			// These are arbitrary actions, and you need to change them.
		case CAST:
			if (monsters.size() > 3)
				results = plyr.castSpell(monsters.get(0), monsters.get(1), monsters.get(2), monsters.get(3));
			else if (monsters.size() < 3)
				results = plyr.castSpell(monsters.get(0));
			else
				results = plyr.castSpell(monsters.get(0), monsters.get(1), monsters.get(2));
			break;
		case DEFEND:
			results = plyr.defend(plyr);
			break;
		}

		out.printInfoIO(results);
	}

	// Clean up the monsters collection, and let remaining monsters do some actions.
	private static void monsterActions() {

		removeDefeatedMonsters();

		for (Monster mnstr : monsters) {
			String[] results;
			int mnstr_choice = Random.rand(2) + 1; // +1 a way to omit DEFEND choice; redesign this
			switch (Actions.values()[mnstr_choice]) {
			case ATTACK:
				results = mnstr.attack(plyr);
				out.printInfoIO(results);
				break;
			case CAST:
				results = mnstr.castSpell(plyr);
				out.printInfoIO(results);
				break;
			}
			// No need to keep attacking if player has no hit points remaining.
			if (plyr.isDead()) {
				// Narrator will give details of losing the game elsewhere.
				return;
			}
		}
	}

	// Monsters with zero hit points should be removed from the monsters collection.
	private static void removeDefeatedMonsters() {
		ArrayList<Monster> temp = new ArrayList<Monster>();
		for (Monster mnstr : monsters)
			if (!mnstr.isDead())
				temp.add(mnstr); // this avoids needing iterators
		monsters = temp;
		data.setMonsters(monsters); // update references to other parts of the game
	}

	// You could add code to print other statistics about the player.
	private static void playerPrintStats() {
		totalPoints = plyr.getHitPoints();
		// stats for the player
		// Babanpreet Kelay
		if (circle.isMonsterOver() || circle.isMonsterOver1() || circle.isMonsterOver2() || circle.isMonsterOver3()
				|| circle.isMonsterOver4() || circle.isMonsterOver5()) {
			for (Monster mnstr : monsters)
				mnstr.isDead();
			out.printInfoIO("Weak Troll has died, You are awarded with some points");
			int totaltrollpoints = plyr.getHitPoints() + 5;
			out.printInfoStats(data.getUserName() + "'s hit points: " + totaltrollpoints);
			out.printBlankLineStats();
		}
//GURKANWALJOT SINGH BRAR		
		else if (circle.atposition1() || circle.atposition2() || circle.atposition3()) {
			graphics.energyDrink.pickedUpDrink();

		} else if (circle.atposition4() || circle.atposition5() || circle.atposition6()) {
			graphics.Apple.pickedUpApple();
		} else {
			out.printInfoStats(data.getUserName() + "'s hit points: " + plyr.getHitPoints());
			out.printBlankLineStats();
		}
	}

	// Prints the stats of remaining monsters---again, you could design more
	// statistics.
	private static void monsterPrintStats() {
		if (!monsters.isEmpty()) {
			String[] results = new String[monsters.size()];
			int k = 0;
			for (Monster mnstr : monsters) {
				results[k++] = "There is " + mnstr.getDescription() + " remaining with " + mnstr.getHitPoints()
						+ " hit points left.";
			}
			out.printInfoStats(results);
		}
	}

	// You should put any code here you want to be the last thing to execute.
	// Maybe a climactic animation?
	private static void finish() {
		// You could have different endings described in the Narrator.
		out.printFancyIO(Narrator.tell());
	}
}
