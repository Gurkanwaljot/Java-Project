package logic;

/**
 * This enum makes it easier to set up code to let the user choose what to do
 * when they are attacked by montsers in the game. Add more choices if you want.
 */
public enum Directions {
	NORTHWEST,
	NORTHEAST,
	SOUTHWEST,
	SOUTHEAST;
	
}
