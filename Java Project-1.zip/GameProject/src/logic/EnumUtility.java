package logic;

public class EnumUtility {


	/**
		 * A method for returning the set of constants as strings in an array.
		 * 
		 * @return
		 *   An array of strings giving the names of the constants 
		 *   inside this Enum, so that this Enum can be used easier.
		 */
		public static String[] getValues(Enum<?> e) {
			int n = e.getDeclaringClass().getEnumConstants().length;
			String[] vals = new String[n];
			int i = 0;
			for (Enum<?> type : e.getDeclaringClass().getEnumConstants())
				vals[i++] = type.toString();
				
			return vals;
		}
		
		/**
		 * A method to get the number of constants in this Enum.
		 * 
		 * @return
		 *   An integer for the number of constants in this Enum.
		 */
		public static int size(Enum<?> e) {
			return e.getDeclaringClass().getEnumConstants().length;
		}
}
