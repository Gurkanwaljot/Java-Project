package Lab10;
/** @Name by Gurkanwaljot Singh Brar
 * @Student Number 300183144
 * Email Address gurkanwaljot.brar@student.ufv.ca
 */
public class Quickselect {
	public static void main(String[] args) {
		testcases();
	}
	public static void testcases() {
		int [] input1 = {1, 7, 8, 3, 2, 4, 6, 5, 9, 14, 12, 13, 11, 10};
		int [] input2 = {1, 7, 8, 3, 2, 4, 6, 5, 9, 14, 12, 13, 11, 10};
		int [] input3 = {10, 26, 14, 2, 4, 8, 28, 6, 20, 12, 30, 16, 22, 18, 24};
		int [] input4 = {10, 26, 14, 2, 4, 8, 28, 6, 20, 12, 30, 16, 22, 18, 24};
		int [] input5 = {10, 26, 14, 2, 4, 8, 28, 6, 20, 12, 30, 16, 22, 18, 24};
		int [] input6 = {3, 40, 22, 7, 62, 8, 99, 22, 120, 55, 144, 35};
		int [] input7 = {3, 40, 22, 7, 62, 8, 99, 44, 120, 55, 144, 35};
		System.out.println("kth smallest number for input1: " + quickselect(input1, 4));
		System.out.println("kth smallest number for input2: " + quickselect(input2, 6));
		System.out.println("kth smallest number for input3: " + quickselect(input3, 2));
		System.out.println("kth smallest number for input4:  "+ quickselect(input4, 3));
		System.out.println("kth smallest number for input5: " + quickselect(input5, 5));
		System.out.println("kth smallest number for input6: " + quickselect(input6, 1));
		System.out.println("kth smallest number for input7: " + quickselect(input7, 4));
		
	}
	/** 
	 * method for findind the kth smallest element inside an array of integers
	 * @param S - an integer array
	 * @param k - index of the smallest value to calculated
	 * @return S[low]- return the value at the lowest index in the array
	 */
	public static int quickselect(int[] S, int k) {
        int low = 0, // Initializing the left-most index of the sub-array
        	high = S.length - 1, // Initializing the variable with value to one less than the length of the integer array S
        	index =low + k -1; // Initializing the right-most index of the sub-array
        // while loop would be implemented till value of low is less than the value of high
        while (low < high) {
            int pivot = partion(S, low, high); // set the pivot inside the array
            if (pivot < index) // statement applicable when pivot is less than index value
            	low = pivot + 1;  
            else if (pivot > index)// statement applicable when pivot is greater than index value 
            	high = pivot - 1;
            else 
            	return S[pivot]; // return the value at index equal to value pivot in the array S.
        }
        return S[low]; //return the value at the lowest index in the array
    }
    /**
     * method that do the partitioning of the array taking pivot as the base of partitioning
     * @param S - integer array
     * @param low- the left-most index of the sub-array
     * @param high- the right-most index of the sub-array
     * @return high - return value of the right-most index of the sub-array
     */
    private static int partion(int[] S, int low, int high) {
        int pivot = low; // setting pivot equal to value of variable low
        //while statement is applicable till low is less than or equal to high
        while (low <= high) {
            while ( S[low] <= S[pivot]) low++ // applicable when value at index 'low' is less than value at index 'pivot' of the array
            			;
            while ( S[high] > S[pivot]) high-- // applicable when value at index 'high' is greater than value at index 'pivot' of the array
            			;
            if (low > high) 
            	break; // function would break when low passes high
            swapReferences(S, low, high); // swaps the elements present at index low and high of the array
        } 
        swapReferences(S, high, pivot); // swaps the elements present at index high and pivot of the array
        return high; //return value of the right-most index of the sub-array
    }
    /**
     * method used for swapping elements inside an array
     * @param S - array of integers
     * @param index1- the index of the first number
     * @param index2- the index of the second number
     */
    public static final void swapReferences( int [ ] S, int index1, int index2 )
    {
        int tmp = S[ index1 ];
        S[ index1 ] = S[ index2 ];
        S[ index2 ] = tmp;
    }
}



