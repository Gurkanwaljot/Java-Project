/**
 * @updated by Gurkanwaljot Singh Brar
 * @Email gurkanwaljot.brar@student.ufv.ca
 *
 */

public class LinkedIntegerList implements SimpleIntegerListADT {

	//Instance variables
	private IntegerNode head;
	private int itemCount;

	/**
	 * Default constructor.
	 */
	public LinkedIntegerList() {
		super();
		this.head = null;
		this.itemCount = 0;
	}

	@Override
	public boolean add(int value) {
		IntegerNode newNode = new IntegerNode(value);
		if(null == this.head) { //Adding to empty list
			this.head = newNode; //Set new node as head
			this.itemCount = 1; //Set item count to 1
			return true;
		}
		else {
			//Find the last node.
			IntegerNode currNode = this.head;
			//Last node does not have a next node (null). Therefore, update the currNode to current nodes' next while it is not null.
			while(null != currNode.getNext()) 
				currNode = currNode.getNext();
			//Set next of last node to new node.
			currNode.setNext(newNode);
			//Increment item count
			this.itemCount++;
			return true;
		}
	}

	@Override
	public boolean add(int index, int value) throws IndexOutOfBoundsException {
		//Check the validity of index.
		if(index < 0 || index > itemCount)
			throw new IndexOutOfBoundsException("The specified index (" + index + ") is not not valid. Index should be between 0 and " + this.itemCount);
		else if(0 == index){ //Add new value as the first (head) element
			IntegerNode newNode = new IntegerNode(value);
			//Update the next node of new node as the current head node
			newNode.setNext(this.head); 
			//Update the head to point to this node
			this.head = newNode;
			//Increment item count
			this.itemCount++;
			return true;
		}
		else {
			IntegerNode newNode = new IntegerNode(value);
			//Find the node at location index-1
			IntegerNode currNode = this.head;
			for(int i=1; i<index; i++) //Note here i goes from 1 to index-1
				currNode = currNode.getNext();
			//Update the new node to point to the next node of the current node.
			newNode.setNext(currNode.getNext());
			//Update the current node to point to the new node.
			currNode.setNext(newNode);
			//Increment item count
			this.itemCount++;
			return true;
		}
	}

	@Override
	public boolean remove(int value) {
		if(null == this.head) // if there is no value in the list which means the list is empty, the result of the boolean expression would be false
			return false;
		else if(this.head.getValue() == value) { // If the head node has the value that needs to be removed the from the list, the particular value would be removed from the list
			this.head = this.head.getNext(); // gets the value on the head node
			this.itemCount--; // deletes the value from the list and reduces the item  count of the list
			return true; // returns the boolean expression to be true
		}	else {
			// if the head node does not have the value that needs to be removed from the list, we use this method here.
			//Search form the first node for the specified value.
			//Here we need to keep a pointer to the current node of the node we are checking.
			IntegerNode currNode = this.head;
			while(null != currNode.getNext()) { // while statment would be implemented only when the list is not empty
				if(currNode.getNext().getValue() == value) { //Next node has the value that should be deleted. Remove it from the list. Set the next of prevNode to next of the next node.
					currNode.setNext(currNode.getNext().getNext());
					itemCount--; // removes the value on the particular node from the list and reduces the item count of that node.
					return true;
				}
				currNode = currNode.getNext(); //Update prevNode to point to the next node (next of prevNode)
			}
			return false; // return the expression to be false if the list is empty.
		}
	}

	@Override
	public int removeAt(int index) throws IndexOutOfBoundsException {
		//Check the validity of index.
		if( index < 0 || index >= this.itemCount) 
			throw new IndexOutOfBoundsException("The specified index (" + index + ") is not present in the list. Number of items present in the list is " + this.itemCount);
		else {
			if(0 == index) {  // removes the head value of the list, if the value mentioned in the question is same as that of the value present at the head of the list
				int value = this.head.getValue(); // gets the value on the particular location in the list to return
				this.head = this.head.getNext(); // sets the pointer on the next of the current head
				itemCount--; // removes the head node from the list and reduces the itemCount related to that node
				return value;
			}
			else {
				// here the pointer moves to the node in the list before that node is removed
				IntegerNode currNode = this.head;
				for (int i = 1; i < index; i++) // here i goes from 1 to index of the list
					currNode = currNode.getNext();
				int value = currNode.getNext().getValue(); // get value at the location of the list to return
				currNode.setNext(currNode.getNext().getNext()); // update previous node to next node to be removed from the list
				itemCount--; // removes the item from the list and reduces its itemCount from the list
				return value; 
				
			}
		}
	}

	@Override
	public int get(int index) throws IndexOutOfBoundsException {
		//Check the validity of index.
		if( index < 0 || index >= this.itemCount) 
			throw new IndexOutOfBoundsException("The specified index (" + index + ") is not present in the list. Number of items present in the list is " + this.itemCount);
		//Get the Node at the index.
		IntegerNode currNode = this.head;
		for(int i=0; i<index; i++) //Note here i goes from 0 to index-1
			currNode = currNode.getNext();
		//return the value of the node.
		return currNode.getValue();
	}

	@Override
	public boolean set(int index, int value) throws IndexOutOfBoundsException {
		if(index < 0 || index >= this.itemCount) // checks the validity of the index whether the given index and value corresponding to it is present in the list
			throw new IndexOutOfBoundsException("The specified index (" + index + ") is not present in the list. Number of items present in the list is " + this.itemCount);
		IntegerNode currNode =  this.head; // gets the node at the given index
		for (int i=0; i<index; i++) { // here i goes from 0 to index
			currNode = currNode.getNext();
		}
		currNode.setValue(value); // this sets value on the given node
		return true;
	}

	@Override
	public int indexOf(int value) {
		if(null == this.head || 0 == this.itemCount) //it checks whether the list is empty 
			return -1;
		IntegerNode currNode = this.head; // sets the node to from the beginning
		int currIndex = 0;
		while (null != currNode) {
			if (currNode.getValue() == value) // when the item is found on the particular node
				return currIndex; // returns the index related to that value
			currNode = currNode.getNext(); // move to next node
			currIndex++; // increments the value of index everytime moving to next node
		}
		return -1; // when item is not present in the list
	}

	@Override
	public boolean contains(int value) {
		//Search using the indexOf method.
		if(this.indexOf(value) >= 0)
			return true;
		else
			return false;
	}

	@Override
	public int size() {
		return this.itemCount;
	}

	@Override
	public void clear() {
		this.head = null;
		this.itemCount = 0;
	}

	@Override
	public String toString() {
		if(null == this.head || 0 == this.itemCount)
			return "List is empty!";
		String retVal = "List Items (Count: " + this.itemCount + "): ";
		IntegerNode currNode = this.head;
		while(null != currNode) {
			retVal += currNode.getValue() + ", ";
			currNode = currNode.getNext();
		}
		return retVal.substring(0, retVal.length()-2);
	}
}
