/**
 * @updated by Gurkanwaljot Singh Brar
 * @Email gurkanwaljot.brar@student.ufv.ca
 *
 */

public class Lab3Tester {
	public static void bar(int x) {
		if (x >= 2)
			bar(x / 2);
		System.out.println(1);
		System.out.print(x % 2 + " ");
	}

	public static void main(String[] args) {
		System.out.println("Integer List");
		LinkedIntegerList myIntegerList = new LinkedIntegerList();

		for (int i = 2; i < 8; i += 2)
			myIntegerList.add(i);
		System.out.println(myIntegerList);
		myIntegerList.add(1, 10);
		System.out.println(myIntegerList);
		myIntegerList.add(66);
		System.out.println(myIntegerList);
		myIntegerList.add(44);
		System.out.println(myIntegerList);

		System.out.println(myIntegerList);
		myIntegerList.remove(66);
		System.out.println(myIntegerList);
		myIntegerList.remove(4);
		System.out.println(myIntegerList);
		myIntegerList.remove(2);
		System.out.println(myIntegerList);
		myIntegerList.removeAt(2);
		System.out.println(myIntegerList);

		myIntegerList.add(0, 44);
		System.out.println(myIntegerList);

		myIntegerList.add(3, 22);
		System.out.println(myIntegerList);

		myIntegerList.add(4, 33);
		System.out.println(myIntegerList);

		myIntegerList.add(5, 55);
		System.out.println(myIntegerList);

		myIntegerList.add(2, 55);
		System.out.println(myIntegerList);

		myIntegerList.removeAt(1);
		System.out.println(myIntegerList);
		myIntegerList.removeAt(3);
		System.out.println(myIntegerList);
		myIntegerList.removeAt(2);
		System.out.println(myIntegerList);

		myIntegerList.set(3, 23);
		System.out.println(myIntegerList);
		myIntegerList.set(2, 15);
		System.out.println(myIntegerList);

		System.out.println(myIntegerList.get(3));

		System.out.println(myIntegerList.indexOf(55));
		System.out.println(myIntegerList.indexOf(34));
		System.out.println(myIntegerList.contains(44));
		System.out.println(myIntegerList.indexOf(44));
		System.out.println(myIntegerList.contains(10));
		System.out.println(myIntegerList.indexOf(10));
		System.out.println(myIntegerList.contains(33));
		System.out.println(myIntegerList.indexOf(33));
		System.out.println(myIntegerList.contains(11));
		System.out.println(myIntegerList.indexOf(11));

		bar(5);
	}

}
