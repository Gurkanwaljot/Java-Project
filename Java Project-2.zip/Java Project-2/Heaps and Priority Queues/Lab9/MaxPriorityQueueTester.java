/**
 * Test class for MPQ
 */
package Lab9;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Malaka Walpola
 * Some parts of this class is taken from the Tree implementation of the textbook.
 * @author: Mark Allen Weiss
 * 
 * @Updated by Gurkanwaljot Singh Brar
 * @Student Number 300183144
 * Email Address gurkanwaljot.brar@student.ufv.ca
 */
public class MaxPriorityQueueTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		test1();
		System.out.println("-----------------Test Case 2-------------------------");
		test2();
	}
	
	public static <E> void test1() {
		Integer[] items = { 20, 30, 40, 80, 70, 60, 50, 10 };
		MaxPriorityQueue<Integer> myQueue = new MaxPriorityQueue<Integer>(Arrays.asList(items));

		myQueue.printMaxPriorityQueue();
		System.out.println("Size of the queue: " + myQueue.size());
		System.out.println("Element with highest priority: " + myQueue.nextElement());
		System.out.println("Removing element with highest priority returns: " + myQueue.remove() );
		System.out.println("Element with highest priority (updatred queue): " + myQueue.nextElement());
		myQueue.add(66);
		myQueue.add(88);
		myQueue.printMaxPriorityQueue();
	}
	
	public static void test2() {
		Integer[] items1 = {1,2,3,4,5,6,7,8,9,10,11}; // new integerList
		MaxPriorityQueue<Integer> myQueue2 = new MaxPriorityQueue<Integer>(Arrays.asList(items1)); // new variable for setting the queues for the items2
		
		myQueue2.printMaxPriorityQueue(); // prints the queue with elements according to their priority level in the heap
		System.out.println("Size of the second queue: " + myQueue2.size()); // prints the size of second queue
		System.out.println("Removing first element with highest priority returns: " + myQueue2.remove() ); // removes the element with highest priority in the queue 
		myQueue2.printMaxPriorityQueue(); // prints the elements of the queue excluding the element removed before
		System.out.println("Removing second element with highest priority returns: " + myQueue2.remove() );// removes the element with highest priority in the queue 
		myQueue2.printMaxPriorityQueue();// prints the elements of the queue with new priority being set excluding the element removed before
		System.out.println("Size of the second queue after removing the elements: " + myQueue2.size()); // prints the size of the queue
		myQueue2.add(15); // adds the element according its priority level in the queue
		myQueue2.add(99); // adds the element according its priority level in the queue
		myQueue2.add(83);// adds the element according its priority level in the queue
		myQueue2.printMaxPriorityQueue(); // prints the queue with new values being added in it
		System.out.println("Size of the second queue after adding the elements: " + myQueue2.size()); // prints the new size of the queue
	}

}
