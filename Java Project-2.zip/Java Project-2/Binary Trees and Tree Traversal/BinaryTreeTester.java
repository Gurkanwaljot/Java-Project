/**
 * 
 */
package Lab6;

/**
 * @author Malaka Walpola
 * This class is taken from the Tree implementation of the textbook.
 * @author: Mark Allen Weiss
 * 
 * @Updated by Gurkanwaljot Singh Brar
 * @Student Number 300183144
 * @Email Address gurkanwaljot.brar@student.ufv.ca
 */
public class BinaryTreeTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		test1();
		test2();
		test3();

	}
	
	private static void test1(){
		BinaryTree<Integer> t1 = new BinaryTree<Integer>();
		BinaryTree<Integer> t2 = new BinaryTree<Integer>();
		BinaryTree<Integer> t3 = new BinaryTree<Integer>();
		BinaryTree<Integer> t4 = new BinaryTree<Integer>();
		BinaryTree<Integer> t5 = new BinaryTree<Integer>();
		BinaryTree<Integer> t6 = new BinaryTree<Integer>(6);
		BinaryTree<Integer> t7 = new BinaryTree<Integer>();
		BinaryTree<Integer> t8 = new BinaryTree<Integer>(8);
		BinaryTree<Integer> t9 = new BinaryTree<Integer>();
		BinaryTree<Integer> t10 = new BinaryTree<Integer>();
		BinaryTree<Integer> t11 = new BinaryTree<Integer>(11);
		//BinaryTree<Integer> t12 = new BinaryTree<Integer>();
		//BinaryTree<Integer> t13 = new BinaryTree<Integer>();
		BinaryTree<Integer> t14 = new BinaryTree<Integer>(14);
		BinaryTree<Integer> t15 = new BinaryTree<Integer>();
		
		t4.merge(4, t8, t9);
		t5.merge(5, t10, t11);
		t7.merge(7, t14, t15);
		t2.merge(2, t4, t5);
		t3.merge(3, t6, t7);
		t1.merge(1, t2, t3);

		System.out.println( "t1 should be a tree with 10 nodes; t2 is empty" );
		System.out.println( "----------------" );
		System.out.println( "t1" );
		t1.printPreOrder();
		System.out.println( "----------------" );
		t1.printInOrder();
		System.out.println( "----------------" );
		t1.printPostOrder();
		System.out.println();
		System.out.println( "----------------" );
		System.out.println( "t2" );
		t2.printPostOrder( );
		System.out.println( "----------------" );
		System.out.println( "t1 size: " + t1.size() );
		System.out.println( "t1 height: " + t1.height() );
	}
	
	//Incomplete Methods
	private static void test2(){
		BinaryTree<String> s1 = new BinaryTree<String>();
		BinaryTree<String> s2 = new BinaryTree<String>();
		BinaryTree<String> s3 = new BinaryTree<String>();
		BinaryTree<String> s4 = new BinaryTree<String>();
		BinaryTree<String> s5 = new BinaryTree<String>("e");
		BinaryTree<String> s6 = new BinaryTree<String>();
		BinaryTree<String> s7 = new BinaryTree<String>("g");
		BinaryTree<String> s8 = new BinaryTree<String>();
		BinaryTree<String> s9 = new BinaryTree<String>("i");
		BinaryTree<String> s10 = new BinaryTree<String>("j");
		BinaryTree<String> s11 = new BinaryTree<String>();
		BinaryTree<String> s12 = new BinaryTree<String>();
		
		s4.merge("z", s11, s9);
		s3.merge("d", s4, s5);
		s2.merge("b", s6, s10);
		s1.merge("a", s2, s3);
		
		System.out.println("s1 should be a tree with 7 nodes; s2 is empty");
		System.out.println( "----------------" );
		System.out.println( "s1" );
		s1.printPreOrder();
		System.out.println();
		s1.printInOrder();
		System.out.println();
		System.out.println( "----------------" );
		System.out.println( "s2" );
		s1.printPostOrder();
		System.out.println( "----------------" );
		System.out.println( "s1 size: " + s1.size() );
		System.out.println( "s1 height: " + s1.height() );
	}
	
	private static void test3(){
		BinaryTree<Integer> d1 = new BinaryTree<Integer>();
		BinaryTree<Integer> d2 = new BinaryTree<Integer>(2);
		BinaryTree<Integer> d3 = new BinaryTree<Integer>(3);
		BinaryTree<Integer> d4 = new BinaryTree<Integer>();
		BinaryTree<Integer> d5 = new BinaryTree<Integer>();
		BinaryTree<Integer> d6 = new BinaryTree<Integer>();
		BinaryTree<Integer> d8 = new BinaryTree<Integer>(8);
		BinaryTree<Integer> d10 = new BinaryTree<Integer>(10);
		BinaryTree<Integer> d12 = new BinaryTree<Integer>(12);
		BinaryTree<Integer> d14 = new BinaryTree<Integer>();
		BinaryTree<Integer> d15 = new BinaryTree<Integer>(15);
		BinaryTree<Integer> d18 = new BinaryTree<Integer>();
		BinaryTree<Integer> d22 = new BinaryTree<Integer>(22);
		BinaryTree<Integer> d26 = new BinaryTree<Integer>(26);
		
		d18.merge(18, d22, d26);
		d14.merge(14, d18, d15);
		d6.merge(6, d14, d12);
		d5.merge(5, d8, d10);
		d4.merge(4, d5, d6);
		d1.merge(1, d2,  d4);
		
		System.out.println("d1 should be a tree with 11 nodes; d2 is empty");
		System.out.println( "----------------" );
		System.out.println( "d1" );
		d1.printPreOrder();
		System.out.println();
		d1.printInOrder();
		System.out.println();
		System.out.println( "----------------" );
		System.out.println( "d2" );
		d1.printPostOrder();
		System.out.println( "----------------" );
		System.out.println( "d1 size: " + d1.size() );
		System.out.println( "d1 height: " + d1.height() );

	}


}
