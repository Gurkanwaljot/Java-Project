/**
 * Test class for AVL Tree.
 */
package Lab8;
/**
 * @author Malaka Walpola
 * Some parts of this class is taken from the Tree implementation of the textbook.
 * @author: Mark Allen Weiss
 * 
 * @Updated by Gurkanwaljot Singh Brar
 * @Student Number 300183144
 * Email Address gurkanwaljot.brar@student.ufv.ca
 */
public class AVLTreeTester {

	public static void main(String[] args) {
		test1();
		System.out.println("--------------Test2-----------------");
		test2();
	}
	
	private static void test2() {
		int [] values2 = {12, 34, 55, 9, 48, 52, 33, 77, 66, 59};
		AVLTree<Integer> myAVLT2 = new AVLTree<Integer>();
		for(int i=0; i<values2.length; i++) {
			myAVLT2.insert(values2[i]);
		}
		
		myAVLT2.printPreOrder(); // 34, 12, 9, 33, 55, 52, 48, 66, 59, 77  END
		myAVLT2.printInOrder(); // 9, 12, 33, 34, 48, 52, 55, 59, 66, 77  END
		myAVLT2.printPostOrder(); // 9, 33, 12, 48, 52, 59, 77, 66, 55, 34  END
		
		myAVLT2.insert(31);
		myAVLT2.insert(62);
		myAVLT2.insert(19);
		myAVLT2.printInOrder(); // 9, 12, 19, 31, 33, 34, 48, 52, 55, 59, 62, 66, 77,  END
		
		myAVLT2.delete(52); // deleting the leaf node
		myAVLT2.printInOrder(); // 9, 12, 19, 31, 33, 34, 48, 55, 59, 62, 66, 77,  END
		
		myAVLT2.delete(62); // deleting node with two child
		myAVLT2.printInOrder(); // 9, 12, 19, 31, 33, 34, 48, 55, 59, 66, 77,  END
		
	}
	
	private static void test1() {
		int [] values = {25, 50, 75, 15, 35, 45, 30, 90, 80, 85};
		AVLTree<Integer> myAVLT = new AVLTree<Integer>();
		for(int i=0; i<values.length; i++) {
			myAVLT.insert(values[i]);
		}
		
		myAVLT.printPreOrder(); //Order of Nodes: 35, 25, 15, 30, 80, 50, 45, 75, 90, 85 END
		myAVLT.printInOrder();	//Order of Nodes: 15, 25, 30, 35, 45, 50, 75, 80, 85, 90 END
		myAVLT.printPostOrder(); //Order of Nodes: 15, 30, 25, 45, 75, 50, 85, 90, 80, 35 END

		myAVLT.delete(15);
		myAVLT.delete(30);
		myAVLT.printInOrder();	//Order of Nodes: 25, 35, 45, 50, 75, 80, 85, 90 END
		
		myAVLT.delete(90);
		myAVLT.printInOrder();	//Order of Nodes: 25, 35, 45, 50, 75, 80, 85 END
		
		myAVLT.insert(30);
		myAVLT.insert(40);
		myAVLT.insert(48);
		myAVLT.insert(82);
		myAVLT.insert(33);
		myAVLT.insert(43);
		myAVLT.insert(20);
		
		myAVLT.delete(35);
		myAVLT.printInOrder();	//Order of Nodes: 20, 25, 30, 33, 40, 43, 45, 48, 50, 75, 80, 82, 85,  END
		
		myAVLT.delete(82);
		myAVLT.printInOrder();	//Order of Nodes: 20, 25, 30, 33, 40, 43, 45, 48, 50, 75, 80, 85,  END
		
		int [] searchValues = { 33, 43, 82, 20, 22};
		for(int i=0; i<searchValues.length;i++) {
			AVLTreeNode<Integer> resultNode = myAVLT.search(searchValues[i]);
			System.out.println((resultNode==null)?("Value " + searchValues[i] + " Not Found!"):("Value " + resultNode.getValue() + " Found!"));
		}
	}

}
