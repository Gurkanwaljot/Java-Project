public class Solution3 {
	public static int[] theMCSS(int[] A) {
		int[] maxSumPoints;
		maxSumPoints = new int[2];
		int maxSum= 0;
		int thisSum= 0;
		int seqStart= -1;
		int seqEnd= -1;
		for(int i=0, j =0; j< A.length; j++) {
			thisSum += A[j];
				if(thisSum > maxSum) {
					maxSum = thisSum;
					seqStart = i;
					seqEnd = j;
					
				} else if(thisSum < 0) {
					thisSum = 0;
					i= j + 1;
				}
		}
		maxSumPoints[0]= seqStart;
		maxSumPoints[1]= seqEnd;
		System.out.println("{"+ maxSumPoints[0] + ", " + maxSumPoints[1] + "}");
		return maxSumPoints;
	}	
}