public class SolutionTester {
	public static void main( String [] args) {
		
		int[] a = {1,3,-5, 7, 4, -2};
		int[] b = { -2, 11, -4, 13, -5, 2};
		int[] c = { -2, -5, -20, -5, -7};
		System.out.println("Solution 1 is given as:");
		Solution1.theMCSS(a);
		Solution1.theMCSS(b);
		Solution1.theMCSS(c);
		
		System.out.println("Solution 2 is given as:");
		Solution2.theMCSS(a);
		Solution2.theMCSS(b);
		Solution2.theMCSS(c);
		
		System.out.println("Solution 3 is given as:");
		Solution3.theMCSS(a);
		Solution3.theMCSS(b);
		Solution3.theMCSS(c);
	}
}
