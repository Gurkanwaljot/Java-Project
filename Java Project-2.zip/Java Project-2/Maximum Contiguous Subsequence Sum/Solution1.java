public class Solution1 {
	public static int[] theMCSS(int [] A) {
		int [] maxSumPoints;
		maxSumPoints = new int[2];
		int maxSum =0;
		int seqStart= -1;
		int seqEnd= -1;
		for(int i =0; i<A.length; i++)
			for (int j=i; j<A.length; j++) {
				int thisSum= 0;
				for( int k=i; k<= j; k++) {
					thisSum += A[k];
				if(thisSum > maxSum) {
					maxSum = thisSum;
					seqStart = i;
					seqEnd = j;
				}
				}
			}
		maxSumPoints[0]= seqStart;
		maxSumPoints[1]= seqEnd;
		System.out.println("{"+ maxSumPoints[0] + ", " + maxSumPoints[1] + "}");
		return maxSumPoints;
		
	}

}