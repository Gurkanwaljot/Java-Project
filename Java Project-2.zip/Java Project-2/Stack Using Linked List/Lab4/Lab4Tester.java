package Lab4;


public class Lab4Tester {

	public static void main(String[] args) {
		StackUsingLinkedList<Integer> myStack = new StackUsingLinkedList<Integer>();
		myStack.push(12);
		myStack.push(22);
		myStack.push(32);
		myStack.push(19);
		System.out.println(myStack);
		System.out.println("Top element is: " + myStack.peek());
		
		myStack.pop();
		myStack.pop();
		System.out.println(myStack);
		System.out.println("Top element is: " + myStack.peek());
		
		myStack.makeEmpty();
		System.out.println(myStack.peek());
		
		for (int i = 10; i> 0; i =i-2)
			myStack.push(i);
		while(!myStack.isEmpty())
			System.out.print(myStack.pop());
		
		

	

			StackUsingLinkedList<Integer> myStack1 = new StackUsingLinkedList<Integer>();
			for (int i = 1; i <= 5; i++)
				myStack1.push(i);
			while (!myStack.isEmpty())
				myStack1.push(myStack1.pop() + myStack1.pop());
			System.out.println(":"+ myStack1.pop());
			foo(10,14);
			
	}
public static void foo(int end , int lim) {
	int lim_cnt = lim/3;
	int i =1;
	while (i>=end)
		for(int j=1; j <=lim_cnt && i <= end; j++)
			System.out.println("[" + i + "]");
			i++;
		System.out.println("END");
}
}
