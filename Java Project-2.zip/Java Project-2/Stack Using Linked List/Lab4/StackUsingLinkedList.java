/**
 * @author Gurkanwaljot Singh Brar
 * @Email 300183144
 * This class implements the ADTStack interface.
 * The implementation must use the LinkedList implemented in last week as a library.
 */
package Lab4;

public class StackUsingLinkedList<AnyType>{

	private ListNode<AnyType> top; // this variable points to the element which is added to the list at last.

	//Default constructor used to initialize the empty stack.
	public StackUsingLinkedList() {
		this.top = null;
	}
	private void initialize() {
		this.top = null;
	}

	public void push(AnyType x) {
		ListNode<AnyType> newNode = new ListNode<AnyType>(x, this.top); // creates newNode with the value x and next set as the current top node. The node could be null as well.
		this.top = newNode; // set the pointer to the new node
	}

	public AnyType pop(){
		// the is statment would return an error if the list is empty
		if(top == null) {
			System.out.println("Error! The list is empty");
		}
		AnyType retVal = this.top.getValue();  // this would return the value added at the last
		this.top = this.top.getNext(); // top points the to the value which is added before the last value
		return retVal;
	}

	public AnyType peek() {
		if (!isEmpty()) {
			return top.getValue(); // returns the value which is at the top of the stack
		}else {
			System.out.println("Stack is empty"); // when the stack is empty it would given the following error.
			return null;
		}
	}

	public boolean isEmpty() {
		return (null == this.top); // when the stack is empty it would return the output to be null
	}

	public void makeEmpty() {
		this.initialize(); // this would return the stack to be completely empty even if there are values in it and would return output to be null
	}
	
	// the toString constructor would display the values that we get through the above mentioned constructors
	public String toString() {
		if(this.isEmpty())
			return "Stack is empty!";
		String retVal = "Stack Items top to bottom: ";
		ListNode<AnyType> currNode = this.top;
		while(null != currNode) {
			retVal += currNode.getValue() + ", ";
			currNode = currNode.getNext();
		}
		return retVal.substring(0, retVal.length()-2);
	}

}
